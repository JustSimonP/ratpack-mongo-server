
import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.*;
import com.mongodb.client.model.Projections;
import org.bson.Document;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MongoOperator {
    MongoCollection collection;

    public MongoOperator() {


        var mongoClient = new MongoClient("localhost", 27017);
        MongoDatabase database = mongoClient.getDatabase("PlantCare");
        collection = database.getCollection("EnvInfo");

    }

    public int insertObject(PlantEnv plantEnv) {

        Document document = new Document();
        document.put("airTemperature", plantEnv.airTemperature);
        document.put("airHumidity", plantEnv.airHumidity);
        document.put("groundHumidity", plantEnv.groundHumidity);
        document.put("light", plantEnv.light);
        document.put("date", Main.getCurrentDateTime());


        collection.insertOne(document);
        return 0;

    }

    public List getAllTemperature() {
        MongoCursor iterator = collection.find().iterator();
        return Collections.emptyList();
    }

    public void returnAllTempRecords() {

        FindIterable<Document> docs =
                collection.find();
        for (Document doc : docs) {
            doc.getString("airTemperature");
            doc.getString("date");
        }
        // .projection(Projections.fields(Projections.include("date")));

    }

    public void parseStringToMongo(String jsonString) {

        collection.insertOne(Document.parse(jsonString));
    }

    public List getAll() {
        var listOfObjects = new ArrayList<String>();


        MongoCursor iterator = collection.find().iterator();
        while (iterator.hasNext()) listOfObjects.add(iterator.next().toString());

        iterator.close();
        return listOfObjects;
    }


}
