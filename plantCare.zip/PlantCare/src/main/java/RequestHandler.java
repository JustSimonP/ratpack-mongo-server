import ratpack.jackson.Jackson;
import ratpack.server.RatpackServer;
import ratpack.server.ServerConfig;

import java.net.URI;

public class RequestHandler {

    //PATH: http://localhost:5050/choosenEndpoint
    public RequestHandler(){
        try {
            RatpackServer.start(ratpackServerSpec ->
                    ratpackServerSpec
                            .serverConfig(ServerConfig.embedded().publicAddress(new URI("http://192.168.1.13:5050")))
                            .handlers(chain ->chain
                            .get("getAll",
                                    context -> context.render(Jackson.json(new MongoOperator().getAll())))
                            .get("test",
                                    context -> context.render(Jackson.json("Connection to server functions properly!")))
                            ));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
