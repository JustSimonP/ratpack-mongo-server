
import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.util.ArrayList;
import java.util.List;

public class MongoOperator {
    MongoCollection collection;

    public MongoOperator() {


        var mongoClient = new MongoClient("localhost", 27017);
        MongoDatabase database = mongoClient.getDatabase("PlantCare");
        collection = database.getCollection("EnvInfo");

    }

    public void insertObject(PlantEnv plantEnv) {

        Document document = new Document();
        document.put("airTemperature", plantEnv.airTemperature);
        document.put("airHumidity", plantEnv.airHumidity);
        document.put("groundHumidity", plantEnv.groundHumidity);
        document.put("light", plantEnv.light);
        document.put("date", plantEnv.dateTime);


        collection.insertOne(document);

    }

    public List getAll() {
        var listOfObjects = new ArrayList<String>();


        MongoCursor iterator = collection.find().iterator();
        while (iterator.hasNext()) listOfObjects.add(iterator.next().toString());

        iterator.close();
        return listOfObjects;
    }


}
